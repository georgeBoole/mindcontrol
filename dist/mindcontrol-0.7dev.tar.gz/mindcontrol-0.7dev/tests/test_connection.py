# test_connection.py
# nothing here yet, stubby

def main():
	pass

if __name__ == '__main__':
	main()